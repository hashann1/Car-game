package com.example.carrace;

interface GameTask
{
    fun closeGame(mScore:Int)
}
